<h1>
	<?php esc_html_e( 'Properties', 'myhome-idx-broker' ); ?>
</h1>

<div id="myhome-idx-broker-import">
	<idx-broker-import></idx-broker-import>
</div>


